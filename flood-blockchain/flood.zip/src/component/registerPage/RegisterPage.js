import React from "react";
import { Row, Col, Form, Button } from "react-bootstrap";
import { Radio } from "antd";


class RegisterPage extends React.Component {
  state = {
    first_name: '',
    last_name: "",
    email: "",
    password: "",
    phone: "",
    address: "",
    user_type:"regular"

  };

  updateField = (type, value) => {
    this.setState({ [type]: value })
  }
  handleRegister = async (e) => {
    e.preventDefault();
    //this.props.form.validateFieldsAndScroll(async (err, values) => {
    //if (!err) {

    const response = await fetch('/api/user/register?first_name=' + this.state.first_name, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        first_name: this.state.first_name,
        last_name: this.state.last_name,
        password: this.state.password,
        email: this.state.email,
        address: this.state.address,
        phone: this.state.phone,
        user_type:this.state.user_type
      }
      ),
    });
    const body = await response.text();
    if (response.status == 422) {
      alert(body);
    }
    if (response.status == 200) {
      let out = JSON.parse(body);
      this.props.onLoginAction(false);
      alert("Login id is " + out.insertId);
    }

    // this.props.history.push("/");
    // }
    //});
  }

  render() {
    return (
      <Row>
        <Col> </Col>
        <Col xs={6}>
          <Form
            style={{
              marginTop: "30px",
              marginBottom: "30px",
              border: "2px solid blue",
              padding: "60px",
              background: "white"
            }}
          > 
          
            <h1 style={{ marginBottom: "20px" }}>Registration</h1>
            <Form.Row>
            <Form.Group as={Col}>
            <Radio.Group onChange={(e)=>this.updateField("user_type",e.target.value)} value={this.state.user_type}>
              <Radio value={"volunteer"}>Volunteer</Radio>
              <Radio value={"regular"}>Regular</Radio>
            </Radio.Group></Form.Group></Form.Row>
            <Form.Row>
              <Form.Group as={Col} controlId="formGridFirstName">
                <Form.Control
                  name="firstName"
                  placeholder="Enter First Name"
                  value={this.state.first_name}
                  onChange={(e) => { this.updateField("first_name", e.target.value) }}
                />
              </Form.Group>

              <Form.Group as={Col} controlId="formGridLastName">
                <Form.Control
                  value={this.state.last_name}
                  onChange={(e) => { this.updateField("last_name", e.target.value) }}
                  name="lastName"
                  placeholder="Last Name"
                />
              </Form.Group>
            </Form.Row>
            <Form.Row>
              <Form.Group as={Col} controlId="formGridEmail">
                <Form.Control
                  name="email"
                  value={this.state.email}
                  onChange={(e) => { this.updateField("email", e.target.value) }}
                  placeholder="Enter email"
                />
              </Form.Group>

              <Form.Group as={Col} controlId="formGridPassword">
                <Form.Control
                  name="password"
                  type="password"
                  value={this.state.password}
                  onChange={(e) => { this.updateField("password", e.target.value) }}
                  placeholder="Password"
                />
              </Form.Group>
            </Form.Row>
            <Form.Group controlId="formPhone">
              <Form.Control
                name="phone"
                value={this.state.phone}
                onChange={(e) => { this.updateField("phone", e.target.value) }}
                placeholder="Mobile Number"
              />
            </Form.Group>

            <Form.Group controlId="formAddress2">
              <Form.Control name="address" value={this.state.address} onChange={(e) => { this.updateField("address", e.target.value) }} placeholder="Address" />
            </Form.Group>
            <Form.Row>
              <Form.Group as={Col}>
                <Button
                  style={{ width: "100%" }}
                  variant="primary"
                  onClick={(e) => { this.handleRegister(e) }}
                >
                  Register
                          </Button>
              </Form.Group>
              {/* <Form.Group as={Col}>
                <Button
                  style={{ width: "100%" }}
                  variant="outline-secondary"
                  type="submit"
                >
                  Login
                          </Button>
              </Form.Group> */}
            </Form.Row>
          </Form>
        </Col>
        <Col> </Col>
      </Row>

    );
  }
}
export default RegisterPage;
