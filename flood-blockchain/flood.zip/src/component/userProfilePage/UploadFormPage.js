import React from 'react';
import { Icon, Upload, Button } from "antd";
import { Form } from "react-bootstrap";
class UploadFormPage extends React.Component {
    state = {
        place: "",
        details: "",
        contact_person: "",
        contact_no: "",
        image_location: "",
    }

    

    onUploadAction = async ()  => {
        let uploadDetails = {...this.state};
        var response = await fetch('api/user/publish' , {
            method: "POST",
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                place: this.state.place,
                details: this.state.details,
                contact_person: this.state.contact_person,
                contact_no: this.state.contact_no,
                image_location: this.state.image_location,
                id:this.props.id,
                first_name: this.props.first_name
            })
    
          });
          const body = await response.text();
          if (response.status == 200) {
            let out = JSON.parse(body);
           alert("uploaded successfully");
           this.props.reloadProfile();
              } else if (response.status == 422) {
            alert("error uploadin");
          }
     
    }
    updateField = (type, value) => {
        console.log(value)
        this.setState({ [type]: value })
    }
    render() {
        return (
            <div>
                <Form style={{ border: "2px solid blue", padding: "10px" }}>
                    <Form.Label style={{ fontSize: "25px" }}>
                        Upload Documents
            </Form.Label>
                    <Form.Group style={{ textAlign: "left" }} controlId="formPlace">
                        <Form.Label>Place</Form.Label>
                        <Form.Control type="text" value={this.state.place} onChange={(e) => { this.updateField("place", e.target.value) }} placeholder="Enter Place" />
                    </Form.Group>
                    <Form.Group
                        style={{ textAlign: "left" }}
                        controlId="exampleForm.ControlTextarea1"
                    >
                        <Form.Label>Details</Form.Label>
                        <Form.Control as="textarea" value={this.state.details} onChange={(e) => { this.updateField("details", e.target.value) }} rows="3" />
                    </Form.Group>
                    <Form.Group style={{ textAlign: "left" }} controlId="formPerson">
                        <Form.Label>Contact Person</Form.Label>
                        <Form.Control type="text" value={this.state.contact_person} onChange={(e) => { this.updateField("contact_person", e.target.value) }} placeholder="contact person" />
                    </Form.Group>
                    <Form.Group style={{ textAlign: "left" }} controlId="formPhone">
                        <Form.Label>Contact Number</Form.Label>
                        <Form.Control type="text" value={this.state.contact_no} onChange={(e) => { this.updateField("contact_no", e.target.value) }} placeholder="contact phone" />
                    </Form.Group>
                    <Form.Group style={{ textAlign: "left" }} label="Upload">
                        <Upload action = "" id="uploadId" name="logo"  
                        beforeUpload = {()=> {return false}}
                        onChange={(e,event) => 

                            {  console.log(e);
                                this.updateField("image_location", e.file.name);
                                 }}  listType="picture">
                            <Button>
                                <Icon type="upload" /> Click to upload
                </Button>
                        </Upload>
                    </Form.Group>
                    <Form.Group style={{ textAlign: "left" }}>
                        <Button
                            style={{
                                width: "50%",
                                background: "#007BFF",
                                color: "white"
                            }}
                            variant="primary"
                            onClick={(e=>{this.onUploadAction()})}
                        >
                            Submit
              </Button>
                    </Form.Group>
                </Form>

            </div>
        )
    }
}
export default UploadFormPage;