import React from 'react';
import { Table, Divider, Tag, Alert, Row, Col, Button,Modal } from 'antd';

  const data = [
    {
      key: '1',
      name: 'John Brown',
      age: 32,
      address: 'New York No. 1 Lake Park',
      tags: ['nice', 'developer'],
    },
    {
      key: '2',
      name: 'Jim Green',
      age: 42,
      address: 'London No. 1 Lake Park',
      tags: ['loser'],
    },
    {
      key: '3',
      name: 'Joe Black',
      age: 32,
      address: 'Sidney No. 1 Lake Park',
      tags: ['cool', 'teacher'],
    },
  ];
  
class AdminHomePage extends React.Component {

    
      
    state = {
        users:[],
        blocks : []
    }

    loadColumns = () => {return  [
        {
          title: 'Id',
          dataIndex: 'id',
          key: 'id'
        },
        {
          title: 'First_Name',
          dataIndex: 'first_name',
          key: 'first_name',
        },
        {
          title: 'Address',
          dataIndex: 'address',
          key: 'address',
        },
         {
          title: 'User Type',
           key: 'user_type',
           dataIndex: 'user_type',
         //  render: user_type => (
        //     <span>
        //       {tags.map(tag => {
        //         let color = tag.length > 5 ? 'geekblue' : 'green';
        //         if (tag === 'loser') {
        //           color = 'volcano';
        //         }
        //         return (
        //           <Tag color={color} key={tag}>
        //             {tag.toUpperCase()}
        //           </Tag>
        //         );
        //       })}
        //     </span>
        //   ),
        },
        {
          title: 'Action',
          key: 'action',
          render: (text, record) => {
              let a= <span></span>;
              if(record.user_type === 'volunteer' && record.is_verified==='N'){
            a = <Button onClick = {()=>this.onApprovalAction(record.id,'Y')}  icon="check"> Approve </Button>  ;
            {/* <span> */}
                {/* <Row> */}
                    {/* <Col span={6}> */}
                           
                    {/* </Col> */}
             {/* <Col span={6}>  <Button  onClick = {()=>this.onApprovalAction(record.id,'N')}   icon="close" >Reject </Button>  */}
             {/* </Col> */}
             {/* </Row> */}
            {/* </span> */}
              }
            return a;
          },
        },
      ];
    }

    componentDidMount = async () => {
        this.loadUserData();
        this.fetchBlockChain();
        
    }

    onApprovalAction = async (id,value) => {
        var response = await fetch('/api/user/approval?id=' + id +'&is_verified='+value, {
            method: "GET",
            headers: {
              'Content-Type': 'application\json',
            },
    
          });
          if (response.status == 200) {
           this.loadUserData();
          }else {
              alert("error on updatin")
          }
    }
    loadUserData = async () => {
        var response = await fetch('/api/users/all', {
            method: "GET",
            headers: {
              'Content-Type': 'application\json',
            },
    
          });
          const body = await response.text();
          if (response.status == 200) {
            let out = JSON.parse(body);
           this.setState({users:out});
          } else if (response.status == 422) {
            alert(body);
          }
    }

    fetchBlockChain= async e =>{
      const response = await fetch('/api/block/getCrowdBlockChain', {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
          },
        });
        const body = await response.text();
      
        if(response.status == 200){
            let out = JSON.parse(body);
            this.setState({ blocks: out.chain });
  
        }
      }
    render() {
      let count = 1;

      let blocks =  this.state.blocks.map(function (block) {
        return  <Col style={{marginBottom:'10px'}}span={3} key={count} ><Block block={block} index={count++} /></Col> ;
});
        return (
            <div>
            <Table columns={this.loadColumns()} dataSource={this.state.users } />
            <Row type="flex" justify="center" align="top">{blocks}</Row>
            </div>
        )
    }
}

class Block extends React.Component {
  state = {
      visible : false
  }

   render () {
      return <div>
      <Button onClick = {() => this.setState({visible: true})} type="primary" icon="box-plot" size={'large'}> { 'Block' + this.props.index } </Button>
      <Modal
      title={'Values of Block ' + this.props.index }
      visible={this.state.visible}
      onOk={() => this.setState({visible: false})}
      onCancel={() => this.setState({visible: false})}

    >
      <p style = {{overflow: 'auto',whiteSpace: 'pre', fontFamily: 'monospace'}}>{JSON.stringify(this.props.block,null, "\t") }</p>
           </Modal>
    </div>
   }
}
export default AdminHomePage;