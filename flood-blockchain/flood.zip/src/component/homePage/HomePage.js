import React from "react";
import { Container, Col, Form, Button, Row, Image } from "react-bootstrap";

const HomePage = () => {
  return (
    <Row>
      <Col sm={7}>
        <h1 style={{ marginTop: "30px" }}>A Blockchain Based Authentication System for Document Digitization in Flood Affected Areas</h1>
        <div
          style={{
            borderRight: "2px  solid",
            color: "red",
            height: "430px",
            padding:"24px",
            marginTop:"48px"
          }}
        >
          <Image src="./homeImg.png" fluid />
        </div>
      </Col>
      <Col sm={5}>
        <div style={{ marginTop: "150px" }}>
          <div>
            <h3 style={{ marginTop: "20px" }}>How does the Technology Work</h3>
            <p>
             In flood affected areas, then the document verification processes by the government are at a slow pace. However, during this time, the government are in a situation to help the people in those areas, by providing compensation for their damaged property and infrastructure, and destructed crops and livestock, etc. To get these compensations, one should claim it by raising a petition to the government, which is a time-consuming process for the petition to reach the respective official and for verification.
      </p>
            <p>
             a blockchain based authentication system for document digitization in flood affected areas is proposed. The people from flood affected areas can raise a request through this application about their losses. The Blockchain mechanism creates all required records as a Block, in which the initial block is considered as a Genisis Block, which leads all further blocks one by one without any intervention. 
      </p>
          </div>
        </div>
      </Col>
    </Row>

  );
};
export default HomePage;
